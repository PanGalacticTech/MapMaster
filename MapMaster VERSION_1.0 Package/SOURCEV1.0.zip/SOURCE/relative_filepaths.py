'''

Testing Methods for using relative filepaths

'''


import os


def replace_backslash(filepath):
    new_filepath = filepath.replace("\\", "/")
    return new_filepath









