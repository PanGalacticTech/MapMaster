#MapMaster DM's Screen Main

import MapMaster_UI as UI

def main():
    GUI = UI.MapMaster_UI()


if __name__ == '__main__':
    main()



